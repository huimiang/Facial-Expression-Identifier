create view view as
  select `train`.`groups`.`subject` AS `SUBJECT`,
         `train`.`groups`.`group`   AS `GROUP`,
         `train`.`imgs`.`no`        AS `NO`,
         `train`.`imgs`.`addr`      AS `addr`,
         `train`.`groups`.`emotion` AS `emotion`
  from (`train`.`groups` join `train`.`imgs` on (((`train`.`groups`.`subject` = `train`.`imgs`.`subject`) and
                                                  (`train`.`groups`.`group` = `train`.`imgs`.`group`))));

